/*******************************************************************************
**
** Filename: tincanwrapper.js
**
** File Description: This file contains the wrapper functions that allows the content
**                   to access the Tin Can functions in the titlemgr frameset.
**
** References: Tin Can API
**
*******************************************************************************/

var finishCalled = false;
var autoCommit = false;
var activityName2 = null;
var activityDesc2 = null;

function MySetValue( lmsVar, lmsVal ) {
 var titleMgr = getTitleMgrHandle();
 if( titleMgr ) titleMgr.setVariable(lmsVar,lmsVal,0);
  getDisplayWindow().LMSSetValue( lmsVar, lmsVal );
}

function loadPage( activityName, activityDesc , activityNameXML) {
 var startDate = readVariable( 'TrivantisSCORMTimer', 0 );
 if( startDate == 0 ) {
	 
	activityName2 = activityName;
 	activityDesc2 = activityDesc; 
	 
	if(activityNameXML)
		getDisplayWindow().LMSInitialize( activityName, activityDesc ,activityNameXML);	
	else
		getDisplayWindow().LMSInitialize( activityName, activityDesc );
	var status = new String( getDisplayWindow().LMSGetValue( "cmi.core.lesson_status" ) );
	status = status.toLowerCase();
	if (status == "not attempted")
		MySetValue( "cmi.core.lesson_status", "attempted" );

	startTimer();
	return true;
 }
 else return false;
}

function startTimer() {
 var startDate = new Date().getTime();
 saveVariable('TrivantisSCORMTimer',startDate);
}

function doBack() {
 MySetValue( "cmi.core.exit", "suspend" );
 saveVariable( 'TrivantisEPS', 'T' );
 finishCalled = true;
 getDisplayWindow().LMSFinish();
 saveVariable( 'TrivantisSCORMTimer', 0 );
}

function doContinue( status ) {
 MySetValue( "cmi.core.exit", "" );
 var mode = new String( getDisplayWindow().LMSGetValue( "cmi.core.lesson_mode" ) );
 mode = mode.toLowerCase();
 if ( mode != "review"  &&  mode != "browse" ) MySetValue( "cmi.core.lesson_status", status );
 saveVariable( 'TrivantisEPS', 'T' );
 finishCalled = true;
 getDisplayWindow().LMSFinish();
 saveVariable( 'TrivantisSCORMTimer', 0 );
}

function doQuit(bForce , notPageUnload){
 saveVariable( 'TrivantisEPS', 'T' );
 finishCalled = true;
 getDisplayWindow().LMSSetValue('',0);
 getDisplayWindow().LMSFinish(notPageUnload);
 saveVariable( 'TrivantisSCORMTimer', 0 );
 if( bForce && getDisplayWindow().myTop ) getDisplayWindow().myTop.close();
}

function unloadPage(bForce, titleName)
{
	var exitPageStatus = readVariable('TrivantisEPS', 'F');
	if (exitPageStatus != 'T')
	{
	    if (window.name.length > 0 && window.name.indexOf('Trivantis_') == -1)
	        trivScormQuit(bForce, titleName, false);
	}
	//LD-5418
	saveVariable( 'TrivantisEPS', 'F' );
}


function findxAPI(win) 
{
   // Search the window hierarchy for the TitleMgr Frame.

   if (win.length > 0)  // does the window have frames?
   {
      if (win.frames['titlemgrframe'] != null)
      {
         return win.frames['titlemgrframe'];
      }

      for (var i=0;i<win.length;i++)
      {
         var theAPI = findxAPI(win.frames[i]);
         if (theAPI != null)
         {
            return theAPI;
         }
      }
   }
   if (parent.frames['titlemgrframe'] != null)
   {
	 return parent.frames['titlemgrframe'];
   }
   return null;   
}

var tcAPI = findxAPI(trivTop());

function LMSInitialize( activityName, activityDesc )
{
  if ( tcAPI )
    return tcAPI.LMSInitialize_( activityName, activityDesc );
  else if ( typeof getDisplayWindow().LMSInitialize_ == 'function' )
    return getDisplayWindow().LMSInitialize_( activityName, activityDesc );
}

function LMSFinish()
{
  if ( tcAPI )
    return tcAPI.LMSFinish_();
  else if ( typeof getDisplayWindow().LMSFinish_ == 'function' )
    return getDisplayWindow().LMSFinish_();
}

function LMSGetValue(name)
{
  if ( tcAPI )
    return tcAPI.LMSGetValue_(name);
  else if ( typeof getDisplayWindow().LMSGetValue_ == 'function' )
    return getDisplayWindow().LMSGetValue_(name);
}

function LMSSetValue(name, value)
{
  if ( tcAPI )
    return tcAPI.LMSSetValue_(name, value);
  else if ( typeof getDisplayWindow().LMSSetValue_ == 'function' )
    return getDisplayWindow().LMSSetValue_(name, value);
}

function LMSCommit()
{
  if ( tcAPI )
    return tcAPI.LMSCommit_();
  else if ( typeof getDisplayWindow().LMSCommit_ == 'function' )
    return getDisplayWindow().LMSCommit_();
}

function LMSGetLastError()
{
  if ( tcAPI )
    return tcAPI.LMSGetLastError();
}

function LMSGetErrorString(errorCode)
{
  if ( tcAPI )
    return tcAPI.LMSGetErrorString(errorCode);
}

function LMSGetDiagnostic(errorCode)
{
  if ( tcAPI )
    return tcAPI.LMSGetDiagnostic(errorCode);
}

function LMSGetBookmark()
{
  if ( tcAPI )
    return tcAPI.LMSGetBookmark_();
  else if ( typeof getDisplayWindow().LMSGetBookmark_ == 'function' )
    return getDisplayWindow().LMSGetBookmark_();
}

function LMSSetBookmark(strHtml,strName)
{
  if ( tcAPI )
    return tcAPI.LMSSetBookmark_(strHtml,strName);
  else if ( typeof getDisplayWindow().LMSSetBookmark_ == 'function' )
    return getDisplayWindow().LMSSetBookmark_(strHtml,strName);
}

function putSCORMInteractions(id,obj,tim,typ,crsp,wgt,srsp,res,lat,txt,chc,answ)
{
  if ( tcAPI )
    return tcAPI.putSCORMInteractions_(id,obj,tim,typ,crsp,wgt,srsp,res,lat,txt,chc,answ);
  else if ( typeof getDisplayWindow().putSCORMInteractions_ == 'function' )
    return getDisplayWindow().putSCORMInteractions_(id,obj,tim,typ,crsp,wgt,srsp,res,lat,txt,chc,answ);
}

function LMSTinCanStatement(strVerb,strObj,strScore)
{
  if ( tcAPI )
    return tcAPI.LMSTinCanStatement_(strVerb,strObj,strScore , activityName2,activityDesc2);
  else if ( typeof getDisplayWindow().LMSTinCanStatement_ == 'function' )
    return getDisplayWindow().LMSTinCanStatement_(strVerb,strObj,strScore, activityName2,activityDesc2);
}

function LMSTinCanSetStatus(strVerb)
{
  if ( tcAPI )
    return tcAPI.LMSTinCanSetStatus_(strVerb);
  else if ( typeof getDisplayWindow().LMSTinCanSetStatus_ == 'function' )
    return getDisplayWindow().LMSTinCanSetStatus_(strVerb);
}

function LMSSetProgressed() 
{
    if (tcAPI)
        return tcAPI.LMSSetProgressed_();
    else if (typeof getDisplayWindow().LMSSetProgressed_ == 'function')
        return getDisplayWindow().LMSSetProgressed_();

}