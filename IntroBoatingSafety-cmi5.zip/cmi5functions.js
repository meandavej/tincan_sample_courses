/*******************************************************************************
 * * * Filename: tincanfunctions.js * * File Description: This file contains
 * several JavaScript functions that are * used to communicate with a Tin Can
 * LRS * * References: Tin Can API *
 ******************************************************************************/

var tcFinishCalled = false;
var ERR_NONE = 0;
var ERR_FROMLMS = 1;
var ERR_INVNUM = 2;
var ERR_INVID = 3;
var ERR_NOLMS = 4;
var ERR_INVINTERACT = 5;
var DEBUG_LMS = 16;

var TinCanVersion = '1.0.0';
var TinCanStmtVersion = '1.0.0';
var TinCanStatus = '';
var TinCanScore = '';
var TinCanCompStatus = '';
var TinCanSatStatus = '';
var TinCanUpdPending = false;
var TinCanProcessing = false;
var TinCanBookmark = '';
var TinCanSuspend = '';
var bDelayTCSuspend = false;
var tc_driver = null;
var tcapi_cache = null;

var bTCCalledFinish = false;
var bTCLoaded = false;
var bTCStatusWasSet = false;
var dTCStart = null;
var dTCEnd = null;
var intAccumulatedMS = 0;
var blnOverrodeTime = false;
var intTimeOverrideMS = null;
var intError = ERR_NONE;
var strErrorDesc = "";

function convertTotalMills(ts)
{
	var Sec = 0;
	var Min = 0;
	var Hour = 0;
	while (ts >= 3600000)
	{
		Hour += 1;
		ts -= 3600000;
	}
	while (ts >= 60000)
	{
		Min += 1;
		ts -= 60000;
	}
	while (ts >= 1000)
	{
		Sec += 1;
		ts -= 1000;
	}
	if (Hour < 10)
		Hour = "0" + Hour;
	if (Min < 10)
		Min = "0" + Min;
	if (Sec < 10)
		Sec = "0" + Sec;
	var rtnVal = Hour + ":" + Min + ":" + Sec;
	return rtnVal;
}

function LMSGetValue_(name)
{
	if (tcFinishCalled == true)
		return "";
	else
	{
		var valString = '';

		if (name == 'cmi.core.lesson_status')
			valString = TinCanStatus;
		else if (name == 'cmi.core.student_name')
			valString = getStudentName(tc_driver.actor);
		else if (name == 'cmi.core.lesson_location')
			valString = LMSGetBookmark();
		else if (name == 'cmi.suspend_data' && TinCanSuspend != null && TinCanSuspend.length > 0)
			valString = TinCanSuspend;
		else if (name == 'cmi.core.session_time')
			valString = convertTotalMills(GetSessionAccumulatedTime());
		else
		{
			ResetErrorStatus();
			if (bTCLoaded)
				valString = TinCanGetInfo(tc_driver, name);
			else
				valString = "";
		}

		if (valString == null)
		{
			if (name == 'cmi.core.score.raw')
				valString = TinCanScore;
			else if (name == 'cmi.suspend_data')
				valString = '';
		}

		if (valString != null)
		{
			if (name == 'cmi.core.score.raw')
				TinCanScore = valString;
			else if (name == 'cmi.suspend_data')
				TinCanSuspend = valString;
		}

		trivLogMsg('LMSGetValue for ' + name + ' = [' + valString + ']', DEBUG_LMS);
		return valString;
	}
}

function LMSGetValue(name)
{
  return LMSGetValue_(name);
}

function LMSSetValue_(name, value)
{
	if (tcFinishCalled != true)
	{
		if (name == 'cmi.core.lesson_status')
			TCSetStatus(value);
		else
		{
			ResetErrorStatus();
			if (bTCLoaded)
			{
				if (name == 'cmi.suspend_data' && value.length >= TinCanSuspend.length - 1
						&& value.length <= TinCanSuspend.length + 1)
					bDelayTCSuspend = true;
				else
				{
					if ( name.length > 0 )
						TinCanSetInfo(tc_driver, name, value);
					if (bDelayTCSuspend)
					{
						TinCanSetInfo(tc_driver, 'cmi.suspend_data', TinCanSuspend);
						bDelayTCSuspend = false;
					}
				}
			}
		}

		if (name == 'cmi.core.score.raw')
		{
			TinCanScore = value;
			TinCanUpdPending = true;
		}
		else if (name == 'cmi.suspend_data')
			TinCanSuspend = value;

		trivLogMsg('LMSSetValue for ' + name + ' to [' + value + ']', DEBUG_LMS);
	}

	return;
}

function LMSSetValue(name, value)
{
  return LMSSetValue_(name, value);
}

function CheckValidInt(intNum)
{
	var str = new String(intNum);
	if (str.indexOf("-", 0) == 0)
		str = str.substring(1, str.length - 1);

	var regValidChars = new RegExp("[^0-9]");
	if (str.search(regValidChars) == -1)
		return true;
	return false;
}

function ConvertToTime(ms)
{
	trivLogMsg("In ConvertToTime ms=" + ms, DEBUG_LMS);
	var retTime = "";
	var hoas;
	var secs;
	var mins;
	var hours;
	var days;
	var mns;
	var yrs;
	var hpm = 100 * 60 * 60 * 24 * (((365 * 4) + 1) / 48);
	hoas = Math.floor(ms / 10);
	yrs = Math.floor(hoas / (hpm * 12));
	hoas -= (yrs * hpm * 12);
	mns = Math.floor(hoas / hpm);
	hoas -= (mns * hpm);
	days = Math.floor(hoas / (100 * 60 * 60 * 24));
	hoas -= (days * 100 * 60 * 60 * 24);
	hours = Math.floor(hoas / (100 * 60 * 60));
	hoas -= (hours * 100 * 60 * 60);
	mins = Math.floor(hoas / (100 * 60));
	hoas -= (mins * 100 * 60);
	secs = Math.floor(hoas / 100);
	hoas -= (secs * 100);
	if (yrs > 0)
	{
		retTime += yrs + "Y";
	}
	if (mns > 0)
	{
		retTime += mns + "M";
	}
	if (days > 0)
	{
		retTime += days + "D";
	}
	if ((hoas + secs + mins + hours) > 0)
	{
		retTime += "T";
		if (hours > 0)
		{
			retTime += hours + "H";
		}
		if (mins > 0)
		{
			retTime += mins + "M";
		}
		if ((hoas + secs) > 0)
		{
			retTime += secs;
			if (hoas > 0)
			{
				retTime += "." + hoas;
			}
			retTime += "S";
		}
	}
	if (retTime == "")
	{
		retTime = "0S";
	}
	retTime = "P" + retTime;
	trivLogMsg("Returning-" + retTime, DEBUG_LMS);
	if(retTime === "P0S")
		retTime = "PT1.11S";
	return retTime;
}

function IsValidDec(strValue)
{
	strValue = new String(strValue);
	if (strValue.search(/[^.\d-]/) > -1)
		return false;
	if (strValue.search("-") > -1)
	{
		if (strValue.indexOf("-", 1) > -1)
			return false;
	}
	if (strValue.indexOf(".") != strValue.lastIndexOf("."))
		return false;
	if (strValue.search(/\d/) < 0)
		return false;
	return true;
}

function isalnum(strValue)
{
	return strValue.search(/\w/) >= 0;
}

function trimleft(str)
{
	str = new String(str);
	return (str.replace(/^\s+/, ''));
}

function trimright(str)
{
	str = new String(str);
	return (str.replace(/\s+$/, ''));
}

// defined again below.
//function Trim(strToTrim)
//{
//	var str = trimleft(trimright(strToTrim));
//	return (str.replace(/\s{2,}/g, " "));
//}

function isurl(urlStr)
{
	return urlStr != null && (urlStr.indexOf("http://") == 0 || urlStr.indexOf("https://") == 0);
}

function TinCanConfigObject( activityName, activityDesc , activityNameXML)
{
	trivLogMsg("TinCanConfigObject", DEBUG_LMS);
	var lrsProps = [ "endpoint", "auth" ];
	var singleProps = [ "activityId","activity_id", "grouping", "activity_platform", "registration", "session" ];
	var singlePropMap = {
		activity_id : "activityId",
		activityId : "activityId",
		grouping : "grouping",
		activity_platform : "activityPlatform",
		registration : "registration",
		session : "session"
	};
	var lrs = {};
	var qsVars = parseSearch();
	var prop;
	var i;

	var result = {
		_isIE : (typeof XDomainRequest !== "undefined"),
		recordStores : [],
		actor : null,
		agentJSON : null,
		activityId : null,
		activityName : {},
		activityDesc : {},
		activityPlatform : null,
		grouping : null,
		registration : null
	};
	
	if(!qsVars.hasOwnProperty("actor"))
		qsVars = parseSearch(true);
	
	if (qsVars.hasOwnProperty("actor"))
	{
		try
		{
			var actor = JSON.parse(qsVars.actor);
			if (actor.mbox !== undefined)
			{
				if (actor.name !== undefined)
					result.actor = {
						name : actor.name,
						mbox : actor.mbox
					};
				else
					result.actor = {
						mbox : actor.mbox
					};
			}
			else if (typeof(actor.account)=="array")
				result.actor = {
					objectType : actor.objectType,
					name : actor.name[0],
					account : {
						name : actor.account[0].accountName,
						homePage : actor.account[0].accountServiceHomePage
					}
				};
			else
				result.actor = {
					objectType : actor.objectType,
					name : actor.name,
					account : {
						name : actor.account["name"],
						homePage : actor.account["homePage"]
					}
				};
			result.agentJSON = JSON.stringify(result.actor);
			delete qsVars.actor;
		} catch (ex)
		{
			trivLogMsg("TinCanConfigObject - failed to parse actor: " + ex, DEBUG_LMS);
		}
	}
	for (i = 0; i < singleProps.length; i += 1)
	{
		prop = singleProps[i];
		if (qsVars.hasOwnProperty(prop))
		{
			result[singlePropMap[prop]] = qsVars[prop];
			delete qsVars[prop];
		}
	}
	if (qsVars.hasOwnProperty("endpoint"))
	{
		for (i = 0; i < lrsProps.length; i += 1)
		{
			prop = lrsProps[i];
			if (qsVars.hasOwnProperty(prop))
			{
				lrs[prop] = qsVars[prop];
				delete qsVars[prop];
			}
		}
		lrs.extended = qsVars;
		lrs.allowFail = false;
		TinCanAddRecordStore(result, lrs);
	}

	result.activityName = activityName;
	result.activityDesc = activityDesc;
	
	if( typeof(activityNameXML) != "undefined" && activityNameXML)
	{
		result.activityName = activityNameXML; 
		result.activityNameXML = activityNameXML;
	}
	
	result.courseActivityObject =
	{
		"objectType": "Activity", 
		"id" : result.activityId,
		"definition" :
		{
			"name" :
			{
				"en-US" : result.activityName
			},
			"description" :
			{
				"en-US" : result.activityDesc
			}
		}
	};

	/*
	 * if(result.recordStores.length===0) { trivLogMsg("TinCanConfigObject -
	 * resulted in no LRS: DATA CANNOT BE STORED", DEBUG_LMS); alert("[error] No
	 * LRS: DATA CANNOT BE STORED"); throw{code:1,mesg:"No LRS: DATA CANNOT BE
	 * STORED"}; }
	 */
	return result;
}

function TinCanAddRecordStore(driver, cfg)
{
	var urlParts;
	var schemeMatches;
	var isXD;

	trivLogMsg("TinCanAddRecordStore", DEBUG_LMS);
	if (!cfg.hasOwnProperty("endpoint"))
	{
		alert("[error] LRS invalid: no endpoint");
		throw {
			code : 3,
			mesg : "LRS invalid: no endpoint"
		};
	}
	if (!cfg.hasOwnProperty("allowFail"))
		cfg.allowFail = true;

	urlParts = cfg.endpoint.toLowerCase().match(/^(.+:)\/\/([^:\/]+):?(\d+)?(\/.*)?$/);
	schemeMatches = location.protocol.toLowerCase() === urlParts[1];
	isXD = (!schemeMatches || location.hostname.toLowerCase() !== urlParts[2] || location.port !== (urlParts[3] !== null ? urlParts[3]
			: (urlParts[1] === 'http:' ? '80' : '443')));
	if (isXD && driver._isIE)
	{
		if (schemeMatches)
		{
			cfg._requestMode = "ie";
			driver.recordStores.push(cfg);
		}
		else
		{
			if (cfg.allowFail)
				alert("[warning] LRS invalid: cross domain request for differing scheme in IE");
			else
			{
				alert("[error] LRS invalid: cross domain request for differing scheme in IE");
				throw {
					code : 2,
					mesg : "LRS invalid: cross domain request for differing scheme in IE"
				};
			}
		}
	}
	else
	{
		cfg._requestMode = "native";
		trivLogMsg("  " + JSON.stringify(cfg, null, 4), DEBUG_LMS);
		driver.recordStores.push(cfg);
	}
}

function TinCanSendStatement(driver, stmt, cbfn)
{
	var lrs, statementId = GenerateRandomID(), cbW, rsCount = driver.recordStores.length, i;

	_TinCanPrepareStatement(driver, stmt);
	var jsonStmt = JSON.stringify(stmt);
	trivLogMsg("TinCanSendStatement:\n" + jsonStmt + "\n", DEBUG_LMS);

	if (rsCount > 0)
	{
		trivLogMsg("  sending...", DEBUG_LMS);
		if (rsCount === 1)
			cbW = cbfn;
		else
		{
			if (typeof cbfn === "function")
			{
				cbW = function()
				{
					trivLogMsg("TinCanSendStatement - cbW: " + rsCount, DEBUG_LMS);
					if (rsCount > 1)
						rsCount -= 1;
					else if (rsCount === 1)
						cbfn.apply(this, arguments);
				};
			}
		}
		for (i = 0; i < rsCount; i += 1)
		{
			lrs = driver.recordStores[i];
			_TinCanXHR_request(lrs, "statements?statementId=" + statementId, "PUT", jsonStmt, cbW);
		}
	}
}

function TinCanSendMultiStatements(driver, stmts, cbfn)
{
	var lrs, cbW, rsCount = driver.recordStores.length, i;

	if (!stmts || !stmts.length || stmts.length < 1)
		return;

	for (i = 0; i < stmts.length; i++)
		_TinCanPrepareStatement(driver, stmts[i]);
	var statementsJson = JSON.stringify(stmts);
	trivLogMsg("  TinCanSendMultiStatements:\n" + statementsJson + "\n", DEBUG_LMS);

	if (rsCount > 0)
	{
		trivLogMsg("  TinCanSendMultiStatements: sending ...", DEBUG_LMS);

		if (rsCount === 1)
			cbW = cbfn;
		else
		{
			if (typeof cbfn === "function")
			{
				cbW = function()
				{
					trivLogMsg("TinCanSendMultiStatements - cbW: " + rsCount, DEBUG_LMS);
					if (rsCount > 1)
						rsCount -= 1;
					else if (rsCount === 1)
						cbfn.apply(this, arguments);
				};
			}
		}
		for (i = 0; i < rsCount; i += 1)
		{
			lrs = driver.recordStores[i];
			_TinCanXHR_request(lrs, "statements", "POST", statementsJson, cbW);
		}
	}
}

function TinCanGetInfo(driver, getKey, cbfn)
{
	trivLogMsg("TinCanGetInfo: " + getKey, DEBUG_LMS);
	if (driver.recordStores.length > 0)
	{
		var lrs = driver.recordStores[0];
		var url = "activities/state?" + "activityId=" + encodeURIComponent(driver.activityId) + "&agent="
				+ encodeURIComponent(driver.agentJSON) + "&stateId=" + encodeURIComponent(getKey);
		if (driver.registration !== null)
			url += "&registration=" + encodeURIComponent(driver.registration);

		var result = _TinCanXHR_request(lrs, url, "GET", null, cbfn, true);
		return (typeof result === "undefined" || result.status === 404) ? null : result.responseText;
	}
}

function TinCanGetStatements(driver, getKey, cbfn)
{
	trivLogMsg("TinCanGetInfo: " + getKey, DEBUG_LMS);
	if (driver.recordStores.length > 0)
	{
		var lrs = driver.recordStores[0];
		var url = "statements?verb=http://adlnet.gov/expapi/verbs/" + encodeURIComponent(getKey);

		var result = _TinCanXHR_request(lrs, url, "GET", null, cbfn, true);
		return (typeof result === "undefined" || result.status === 404) ? null : result.responseText;
	}
}

function TinCanGetCmi5MoveOn(driver , getKey )
{
	if(driver && driver.recordStores[0] && driver.recordStores[0].endpoint)
	{
		var resp;
		var xmlHttp;
		var idx, url;
		
		url =  driver.recordStores[0].endpoint + "statements?verb=http://adlnet.gov/expapi/verbs/" + encodeURIComponent(getKey);
		
		xmlHttp = new XMLHttpRequest();
		
		 if(xmlHttp != null)
			{
				var headers = {}; 
				driver.recordStores[0].auth;
				
				headers["Content-Type"] = "application/json";
				headers["X-Experience-API-Version"] = TinCanVersion;
				
				if( driver.recordStores[0].auth.indexOf("Basic")==0)
					headers["Authorization"] = driver.recordStores[0].auth;
				else
					headers["Authorization"] = "Basic " +driver.recordStores[0].auth;
				
				xmlHttp.open( "GET", url , false );
				
				for ( var headerName in headers)
					xmlHttp.setRequestHeader(headerName, headers[headerName]);
				
				
				xmlHttp.send( null );

				
				resp = JSON.parse(xmlHttp.responseText);

				//Make sure moveon has not been sent for the current activity
				if(resp && resp.statements)
				{
					for (var i = 0; i < resp.statements.length; i++)
					{
						if(resp.statements[i] && resp.statements[i].object 
						&& resp.statements[i].object.definition && resp.statements[i].object.definition.name)
						{
							var compObj = resp.statements[i].object.definition.name["en-US"];
							if( compObj === driver.activityName )
							{
								var statementString = JSON.stringify(resp.statements[i]);

								if(statementString.indexOf('moveon') != -1 && statementString.indexOf(getKey) != -1 )
				                			return true;
							}
						} 	
					}	
					return false;
				} 
				return false; 
			}
	}	
	else
		return false;
}


function TinCanSetInfo(driver, setKey, setVal, cbfn)
{
	trivLogMsg("TinCanSetInfo: " + setKey, DEBUG_LMS);
	if (driver.recordStores.length > 0)
	{
		var lrs = driver.recordStores[0];
		var url = "activities/state?" + "activityId=" + encodeURIComponent(driver.activityId) + "&agent="
				+ encodeURIComponent(driver.agentJSON) + "&stateId=" + encodeURIComponent(setKey);
		if (driver.registration !== null)
			url += "&registration=" + encodeURIComponent(driver.registration);

		_TinCanXHR_request(lrs, url, "PUT", setVal, cbfn);
	}
}

function TinCanISODateString(d)
{
	function pad(val, n)
	{
		if (val == null)
			val = 0;
		if (n == null)
			n = 2;

		var padder = Math.pow(10, n - 1);
		var tempVal = val.toString();
		while (val < padder && padder > 1)
		{
			tempVal = '0' + tempVal;
			padder = padder / 10;
		}
		return tempVal;
	}
	return d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate()) + 'T' + pad(d.getUTCHours())
			+ ':' + pad(d.getUTCMinutes()) + ':' + pad(d.getUTCSeconds()) + '.' + pad(d.getUTCMilliseconds(), 3) + 'Z';
}

function _TinCanPrepareStatement(driver, stmt)
{
	if (stmt.actor === undefined)
		stmt.actor = driver.actor;
	if (driver.grouping || driver.registration || driver.activityPlatform)
	{
		if (!stmt.context)
			stmt.context = {};
	}
	
	//Timing issues would cause grouping to be null default to our standards
	var objectType = driver.grouping && driver.grouping.objectType ? driver.grouping.objectType : "Activity";
	var actID = driver.grouping && driver.grouping.id ? driver.grouping.id : driver.activityIdXML;
	
	//cmi5 Requires contextActivities
	 if (!stmt.context.contextActivities)
	     stmt.context.contextActivities = {};
	 if (!stmt.context.contextActivities.grouping)
	     stmt.context.contextActivities.grouping = {};
	 if (!stmt.context.contextActivities.category)
	     stmt.context.contextActivities.category = {};
	 stmt.context.contextActivities.grouping = {
	 "objectType": objectType,
     "id": actID,
	 "definition" : {
	     "name" : {
	     "en-US" :  driver.activityName
	     },
	     "description" : {
	     "en-US" : driver.activityDesc
	     }
	 }
	 };
     stmt.context.contextActivities.category = {
	 "objectType" : "Activity",
	 "id": "https://w3id.org/xapi/cmi5/context/categories/cmi5"
	 };
	 
	 //If passed statement add the moveOn id
	 //Only moveOn if the object is title or AU
	 if(stmt.verb && stmt.verb.display && stmt.verb.display["und"] 
	 && (stmt.verb.display["und"] == "passed" || stmt.verb.display["und"] == "completed" )
	 && stmt.object.definition.name["en-US"] == tc_driver.activityName)
	 {
		stmt.context.contextActivities.category = [ 
			{
			 "objectType" : "Activity",
			 "id": "https://w3id.org/xapi/cmi5/context/categories/cmi5"
			 },
			{
			  "objectType": "Activity",
			  "id": "https://w3id.org/xapi/cmi5/context/categories/moveon"
			}
			];
	 }
	 

	 if(stmt.verb && stmt.verb.display && stmt.verb.display["und"] 
	 && ( ( stmt.verb.display["und"] != "passed" && stmt.verb.display["und"] != "completed" ) 
	 || stmt.object.definition.name["en-US"] != tc_driver.activityName))
			delete stmt.context.contextActivities.category;


	if (driver.registration)
		stmt.context.registration = driver.registration;
	if (driver.activity_platform)
		stmt.context.platform = driver.activityPlatform;
	
	if(driver.session)
	{
		if(!stmt.context.extensions)
			stmt.context.extensions = {}
		
		stmt.context.extensions = {
			"https://w3id.org/xapi/cmi5/context/extensions/sessionid": driver.session,
			"https://w3id.org/xapi/cmi5/context/extensions/masteryscore": driver.masteryScore
			}
	}
}

function _TinCanXHR_request(lrs, url, method, data, cbfn, ignore404, extraHeaders)
{
	var xhr;
	var finished = false;
	var ieXDomain = (lrs._requestMode === "ie");
	var ieModeRequest;
	var result;
	var extended;
	var until;
	var fullUrl = lrs.endpoint + url;

	trivLogMsg("_TinCanXHR_request: " + url, DEBUG_LMS);
	if (lrs.extended !== undefined)
	{
		extended = [];
		for ( var prop in lrs.extended)
		{
			if (lrs.extended[prop] != null && lrs.extended[prop].length > 0)
				extended.push(prop + "=" + encodeURIComponent(lrs.extended[prop]));
		}
		if (extended.length > 0)
			fullUrl += (fullUrl.indexOf("?") > -1 ? "&" : "?") + extended.join("&");
	}
	var headers = {};
	headers["Content-Type"] = "application/json";
	
	if( lrs.auth && lrs.auth.indexOf("Basic")==0)
		headers["Authorization"] = lrs.auth;
	else
		headers["Authorization"] = "Basic " + lrs.auth;
	
	headers["X-Experience-API-Version"] = TinCanVersion;
	if (extraHeaders !== null)
	{
		for ( var headerName in extraHeaders)
			headers[headerName] = extraHeaders[headerName];
	}
	if (lrs._requestMode === "native")
	{
		trivLogMsg("_TinCanXHR_request using XMLHttpRequest", DEBUG_LMS);
		xhr = new XMLHttpRequest();
		xhr.open(method, fullUrl, cbfn !== undefined || method === 'PUT'); // force async PUT
		for ( var headerName in headers)
			xhr.setRequestHeader(headerName, headers[headerName]);
	}
	else if (ieXDomain)
	{
		trivLogMsg("_TinCanXHR_request using XDomainRequest", DEBUG_LMS);
		ieModeRequest = _TinCanGetIEModeRequest(method, fullUrl, headers, data);
		xhr = new XDomainRequest();
		xhr.open(ieModeRequest.method, ieModeRequest.url, method === 'PUT'); // force async PUT
	}

	function _TinCanXHR_requestComplete()
	{
		trivLogMsg("_TinCanXHR_requestComplete: " + finished + ", xhr.status: " + xhr.status, DEBUG_LMS);
		var notFoundOk;
		if (!finished)
		{
			finished = true;
			notFoundOk = (ignore404 && xhr.status === 404);
			if (xhr.status === undefined || (xhr.status >= 200 && xhr.status < 400) || notFoundOk)
			{
				if (cbfn)
					cbfn(xhr);
				else
				{
					result = xhr;
					return xhr;
				}
			}
			else
			{
				if (xhr.status > 0)
					alert("[warning] There was a problem communicating with the Learning Record Store. (" + xhr.status
							+ " | " + xhr.responseText + ")");
				return xhr;
			}
		}
		else
			return result;
	}
	xhr.onreadystatechange = function()
	{
		if (xhr.readyState === 4)
		{
			_TinCanXHR_requestComplete();
		}
	};
	xhr.onload = _TinCanXHR_requestComplete;
	xhr.onerror = _TinCanXHR_requestComplete;
	xhr.send(ieXDomain ? ieModeRequest.data : data);
	if (!cbfn)
	{
		if (ieXDomain)
		{
			until = 1000 + Date.now();
			trivLogMsg("_TinCanXHR_request: until: " + until + ", finished: " + finished, DEBUG_LMS);
			while (Date.now() < until && !finished)
				__delay();
		}
		return _TinCanXHR_requestComplete();
	}
}

function _TinCanGetIEModeRequest(method, url, headers, data)
{
	var newUrl = url;
	var formData = [];
	var qsIndex = newUrl.indexOf('?');
	var result;

	trivLogMsg("_TinCanGetIEModeRequest", DEBUG_LMS);
	if (qsIndex > 0)
	{
		formData.push(newUrl.substr(qsIndex + 1));
		newUrl = newUrl.substr(0, qsIndex);
	}
	newUrl = newUrl + '?method=' + method;
	if (headers !== null)
	{
		for ( var headerName in headers)
			formData.push(headerName + "=" + encodeURIComponent(headers[headerName]));
	}
	if (data !== null)
		formData.push('content=' + encodeURIComponent(data));

	result = {
		method : "POST",
		url : newUrl,
		headers : {},
		data : formData.join("&")
	};
	return result;
}

function __delay()
{
	var xhr = new XMLHttpRequest();
	var url = window.location + '?forcenocache=' + GenerateRandomID();

	xhr.open('GET', url, false);
	xhr.send(null);
}

function parseSearch(bForceWindow)
{
	if(bForceWindow === undefined)
		bForceWindow = false;

	var oGetVars = {};
	function buildValue(sValue)
	{
		if (/^\s*$/.test(sValue))
			return null;

		if (/^(true|false)$/i.test(sValue))
			return sValue.toLowerCase() === "true";

		if (isFinite(sValue))
			return parseFloat(sValue);

		return sValue;
	}
	var search = '';
	try { search = window.parent.location.search; } catch (e) { }
	if (search.length <= 1 || bForceWindow)
		search = window.location.search;

	if (search.length > 1)
	{
		var aItKey;
		var nKeyId;
		var aCouples = search.substr(1).split("&");

		for (nKeyId = 0; nKeyId < aCouples.length; nKeyId++)
		{
			aItKey = aCouples[nKeyId].split("=");
			oGetVars[unescape(aItKey[0])] = aItKey.length > 1 ? buildValue(unescape(aItKey[1])) : null;
		}
	}
	
	if(oGetVars.fetch && !(tc_driver && tc_driver.recordStores[0] && tc_driver.recordStores[0].auth))
	{
		var resp = '';
		var xmlHttp;
		var idx, url;
		idx =  oGetVars["fetch"].lastIndexOf("&")
		url = oGetVars["fetch"];//.substr(0, idx);
		delete oGetVars.fetch;
		xmlHttp = new XMLHttpRequest();
		
		 if(xmlHttp != null)
			{
				xmlHttp.open( "POST", url, false );
				xmlHttp.send( null );
				resp = xmlHttp.responseText;
				
				var auth = JSON.parse(resp);
				
				if(auth["auth-token"])
					oGetVars["auth"] = auth["auth-token"];
				else {
					if(window.localStorage.getItem('launch.Data'))
						oGetVars["auth"]  = window.localStorage.getItem('launch.Data')
				}
			}
			
			
		var fetchVars = {};	
		var strFetch = url.substr( url.lastIndexOf("?"), url.length)
		if (strFetch.length > 1)
		{
			
			var aItKey;
			var nKeyId;
			var aCouples = strFetch.substr(1).split("&");

			for (nKeyId = 0; nKeyId < aCouples.length; nKeyId++)
			{
				aItKey = aCouples[nKeyId].split("=");
				oGetVars[unescape(aItKey[0])] = aItKey.length > 1 ? buildValue(unescape(aItKey[1])) : null;
			}
			
			delete oGetVars.extCfg;
			
		}		
	}
	else if(tc_driver && tc_driver.recordStores[0] && tc_driver.recordStores[0].auth) 
	{
		oGetVars["auth"] = tc_driver.recordStores[0].auth;
		
		if(tc_driver.session)
			oGetVars["session"]	=	tc_driver.session;
	}
	
	
	trivLogMsg("parseSearch: " + JSON.stringify(oGetVars, null, 4), DEBUG_LMS);
	return oGetVars;
}

function GenerateRandomID()
{
	return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c)
	{
		var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
		return v.toString(16);
	});
}

if (!window.JSON)
{
	window.JSON = {
		parse : function(sJSON)
		{
			return eval("(" + sJSON + ")");
		},
		stringify : function(vContent)
		{
			if (vContent instanceof Object)
			{
				var sOutput = "";
				if (vContent.constructor === Array)
				{
					for (var nId = 0; nId < vContent.length; sOutput += this.stringify(vContent[nId]) + ",", nId++)
					{
					}
					return "[" + sOutput.substr(0, sOutput.length - 1) + "]";
				}
				if (vContent.toString !== Object.prototype.toString)
					return "\"" + vContent.toString().replace(/"/g, "\\$&") + "\"";

				for ( var sProp in vContent)
					sOutput += "\"" + sProp.replace(/"/g, "\\$&") + "\":" + this.stringify(vContent[sProp]) + ",";

				return "{" + sOutput.substr(0, sOutput.length - 1) + "}";
			}
			return typeof vContent === "string" ? "\"" + vContent.replace(/"/g, "\\$&") + "\"" : String(vContent);
		}
	};
}

function getTcDriver( activityName, activityDesc , activityNameXML ) {
	return new Promise(function (resolve, reject) {
		if (!tc_driver){
			tc_driver = TinCanConfigObject( activityName, activityDesc ,activityNameXML);
		}
		resolve(tc_driver);
	});
}

function TinCanConfigObjectWithLaunchData( tc_driver , launchData )
{
    tc_driver.launchData = launchData;

	if(launchData.contextTemplate.contextActivities.grouping)
	{	
		tc_driver.grouping = {};
		tc_driver.grouping = launchData.contextTemplate.contextActivities.grouping[0];
	}

    if(launchData.contextTemplate.extensions && launchData.contextTemplate.extensions["https://w3id.org/xapi/cmi5/context/extensions/sessionid"])
        tc_driver.session = launchData.contextTemplate.extensions["https://w3id.org/xapi/cmi5/context/extensions/sessionid"];
	
	if(launchData.masteryScore)
		tc_driver.masteryScore = launchData.masteryScore;
}

function LMSInitialize_( activityName, activityDesc , activityNameXML )
{
	trivLogMsg("In LMSInitialize", DEBUG_LMS);
	tcapi_cache = {
		totalPrevDuration : null,
		statementQueue : []
	};
	
	if(typeof(tc_driver) != "undefined" && tc_driver != null )
		return true; //We have already initialized this session cmi5 only allows it once
			
	
	getTcDriver( activityName, activityDesc ,activityNameXML).then((tc_driver) => {
			TinCanGetInfo(tc_driver, 'cumulative_time', function(xhr)
			{
				if (xhr.status < 400)
				{
					if (xhr.responseText.match(/^\d+$/))
						tcapi_cache.totalPrevDuration = Number(xhr.responseText);
					else
						tcapi_cache.totalPrevDuration = 0;
					trivLogMsg('tcapi_cache.totalPrevDuration=' + tcapi_cache.totalPrevDuration);
				}
			});
			
			TinCanGetInfo(tc_driver , 'LMS.LaunchData' , function(xhr)
			{
				if(xhr.status < 400)
				{
					var launchData = JSON.parse(xhr.responseText);
					TinCanConfigObjectWithLaunchData ( tc_driver , launchData  );

					//Initialized can only be sent once per sesssion
					TinCanGetStatements(tc_driver, "initialized", function(cbf)
					{
						if(cbf.status < 400)
						{
							if(cbf.responseText.indexOf(tc_driver.session) == -1)
							{

								TinCanStatus = 'attempted';
								TinCanProcessing = true;
								var stmt = {
									"verb" : {
										"id" : "http://adlnet.gov/expapi/verbs/initialized",
										"display" : {
											"en-US" : "initialized"
										}
									},
									"object" : tc_driver.courseActivityObject,
									"timestamp" : TinCanISODateString(new Date()),
									"version" : TinCanVersion
								};
								TinCanSendStatement(tc_driver, stmt, function(xhr)
								{
								});
							}
						}
					});


					InitializeExecuted(true, "");
					return true;
					
				}
			})
	});
}

function LMSInitialize( activityName, activityDesc , activityNameXML)
{
	if(activityNameXML)
		LMSInitialize_( activityName, activityDesc, activityNameXML );
	else
		LMSInitialize_( activityName, activityDesc );
}

function LMSFinish_()
{
	trivLogMsg("In LMSFinish", DEBUG_LMS);

	if(!tcFinishCalled)
	{
		tcFinishCalled = true;
		TinCanFinish("SUSPEND");
		TinCanSendStatement(tc_driver, {
			verb : {
				"id" : "http://adlnet.gov/expapi/verbs/terminated",
				"display" : {
					"en" : "terminated"
				}
			},
			result : {
				"duration" : ConvertToTime(GetSessionAccumulatedTime())
			},
			timestamp : TinCanISODateString(new Date()),
			version: TinCanVersion,
			object: {
				id : tc_driver.activityId,
				objectType : "Activity",
				definition : {
					name : {
						"en-US" : tc_driver.activityName
					},
					description : {
						"en-US" : ""
					}
				}
			}
		}, function()
		{

			window.localStorage.setItem('launch.Data', '' );
			var returntUrl = "";
			if (tc_driver.launchData["returnUrl"])
				returntUrl = tc_driver.launchData["returnUrl"];
			if(tc_driver.launchData["returnURL"])
				returntUrl = tc_driver.launchData["returnURL"];
			
			returntUrl = decodeURIComponent(returntUrl);

			if (window.myTop){
				if(returntUrl != "" && tc_driver.launchData["launchMethod"] == "AnyWindow" )
					window.myTop.location.href = returntUrl;
				else
					window.myTop.close();
			}
			return true;

		});
	}
}

function LMSFinish(notPageUnload)
{
	if(typeof(notPageUnload)!="undefined" && notPageUnload)
		return LMSFinish_();
}

function getStudentName(actor)
{
	if (actor === undefined)
		return "";
	if (actor.name !== undefined)
		return actor.name;
	if (actor.lastName != undefined && actor.firstName != undefined)
		return actor.firstName + " " + actor.lastName;
	if (actor.familyName != undefined && actor.givenName != undefined)
		return actor.givenName + " " + actor.familyName;
	if (actor.mbox !== undefined)
		return actor.mbox.replace('mailto:', '');
	if (actor.account !== undefined)
		return actor.account.accountName;

	return truncateString(JSON.stringify(actor), 20);
}

function LMSRecordInteraction(strID, strResponse, blnCorrect, strCorrectResponse, strDescription, intWeighting,
		intLatency, strLearningObjectiveID, dtmTime, interactType, arChoices, arAnswers)
{

	var validLearningObjectiveID = createValidIdentifier(window.strTestName), // set in TMPr.processTest
		stmt,
		bNeutral = false,
		actObj = {
		"id" : tc_driver.activityId + "/" + createValidIdentifier(strID),
		"definition" : {
			"name" : {
				'en-US' : strDescription
			},
			"description" : {
				'en-US' : strDescription
			},
			"type" : "http://adlnet.gov/expapi/activities/cmi.interaction",
			"interactionType" : interactType,
			"correctResponsesPattern" : [ strCorrectResponse ]
		}
		},
		definition = actObj.definition;
	ResetErrorStatus();
	switch (interactType) {
	case "matching":
		definition.source = [];
		for (var i = 0; i < arChoices.length; i++)
		{
			definition.source.push({
	            "id": arChoices[i],
	            "description": {
	                "en-US": arChoices[i]
	            }
	        });
		}
		definition.target = [];
		for (var i = 0; i < arAnswers.length; i++)
		{
			var answer = arAnswers[i];
			
			for( var hyphenLoc = answer.indexOf('-') ; hyphenLoc >= 0 ; hyphenLoc = answer.indexOf('-') )
			{
				var target;
				var orLoc = answer.indexOf('|');
				
				if(orLoc >= 0)
					target = answer.substring(hyphenLoc+1, orLoc);
				else 
					target = answer.substring(hyphenLoc+1);
				
				if( !ArrContainsTarget(definition.target, target) )
				{
					definition.target.push({
						"id": target,
						"description": {
							"en-US": target
						}
					});
				}
				
				if(orLoc >= 0)
					answer = answer.substring(orLoc+1);
				else 
					break;
			}
		}
		break;
	case "performance":
		definition.steps = [];
		break;
	case "sequencing":
		definition.choices = [];
		for (var i = 0; i < arChoices.length; i++)
		{
			definition.choices.push({
	            "id": arChoices[i],
	            "description": {
	                "en-US": arChoices[i]
	            }
	        });
		}
		break;
	case "likert":
		definition.scale = [];
		for (var i = 0; i < arChoices.length; i++)
		{
			definition.scale.push({
	            "id": arChoices[i],
	            "description": {
	                "en-US": arChoices[i]
	            }
	        });
		}
		bNeutral = true;
		break;
	case "choice":
		definition.choices = [];
		for (var i = 0; i < arChoices.length; i++)
		{
			definition.choices.push({
	            "id": arChoices[i],
	            "description": {
	                "en-US": arChoices[i]
	            }
	        });
		}

		break;
	case "true-false":
	case "fill-in":
	case "numeric":
	case "other":
		break;
	default:
		trivLogMsg("LMSRecordInteraction received an invalid interactType of " + interactType, DEBUG_LMS);
		return false;
	}

	if (actObj.id !== null)
	{
		if (dtmTime == null)
			dtmTime = TinCanISODateString(new Date());
		stmt = {
			verb : {
				"id" : "http://adlnet.gov/expapi/verbs/answered",
				"display" : {
					"und" : "answered"
				}
			},
			object : actObj,
			timestamp: dtmTime,
    		version : TinCanVersion,
			context : {
				contextActivities : {
					parent : {
						"id" : tc_driver.activityId + '/' + validLearningObjectiveID,
						"definition" : {
							"name" : {
								"en-US" : window.strTestName
							},
							"description" : {
								"en-US" : window.strTestName
							}
						}
					},
					grouping : tc_driver.courseActivityObject
				}
			}
		};
		if (strResponse != null)
		{
			if (bNeutral)
				stmt.result = {
					response : strResponse
				};
			else
				stmt.result = {
					response : strResponse,
					success : blnCorrect
				};
		}
		tcapi_cache.statementQueue.push(stmt);
	}
	return true;
}

function ArrContainsTarget(arr, id)
{
	for(var i = 0 ; i < arr.length ; i++)
	{
		if(arr[i].id == id)
			return true;
	}
	
	return false;
}

function TCAPI_SetSuspended()
{
	if (TinCanProcessing)
	{
		TinCanProcessing = false;
		TinCanUpdPending = true;
	}
	return true;
}

function TCAPI_GetLastError()
{
	if (intTCAPIError === '')
		return ERR_NONE;
	else
		return intTCAPIError;
}

function InitializeExecuted(blnSuccess, strErrorMessage)
{
	trivLogMsg("In InitializeExecuted, blnSuccess=" + blnSuccess + ", strErrorMessage=" + strErrorMessage, DEBUG_LMS);
	if (!blnSuccess)
	{
		trivLogMsg("ERROR - LMS Initialize Failed", DEBUG_LMS);
		if (strErrorMessage == "")
			strErrorMessage = "An Error Has Occurred";

		DisplayError(strErrorMessage);
		return;
	}
	bTCLoaded = true;
	if(tc_driver && tc_driver.recordStores[0] && tc_driver.recordStores[0].auth) 
	{
		var strAuth = tc_driver.recordStores[0].auth;
		window.localStorage.setItem('launch.Data', strAuth );
	}

	dTCStart = new Date();
	return;
}

function TinCanFinish(ExitType)
{
	trivLogMsg("In TinCanFinish, ExitType=" + ExitType, DEBUG_LMS);
	ResetErrorStatus();
	if (bTCLoaded && !bTCCalledFinish)
	{
		bTCCalledFinish = true;

		//
		// if the status was set it would have already been recorded.
		//
		// if(TinCanStatus==='completed'||TinCanStatus==='passed')
		// {
		// ExitType="FINISH";
		// TinCanCompStatus='true';
		// TinCanProcessing=false;
		// TinCanUpdPending=true;
		// }

		if (ExitType === "SUSPEND")
		{
			TinCanSetInfo(tc_driver, 'cumulative_time', GetPreviouslyAccumulatedTime() + GetSessionAccumulatedTime());
			TCAPI_SetSuspended();
		}
		LMSCommit();
		bTCLoaded = false;
	}
	return true;
}

function DisplayError(strMessage)
{
	trivLogMsg("In DisplayError, strMessage=" + strMessage, DEBUG_LMS);
	alert("An error has occured:\n\n" + strMessage);
}

function GetLastError()
{
	trivLogMsg("In GetLastError, intError=" + intError, DEBUG_LMS);
	if (intError != ERR_NONE)
	{
		trivLogMsg("Returning API Error", DEBUG_LMS);
		return intError;
	}
	else if (bTCLoaded && TCAPI_GetLastError() != ERR_NONE)
	{
		trivLogMsg("Returning LMS Error", DEBUG_LMS);
		return ERR_FROMLMS;
	}
	trivLogMsg("Returning No Error", DEBUG_LMS);
	return ERR_NONE;
}

function GetLastLMSErrorCode()
{
	var LMSError = TCAPI_GetLastError();

	trivLogMsg("In GetLastLMSErrorCode, intError=" + intError, DEBUG_LMS);
	if (bTCLoaded && LMSError != ERR_NONE)
	{
		trivLogMsg("Returning LMS Error: " + LMSError, DEBUG_LMS);
		return LMSError;
	}
	trivLogMsg("Returning No Error", DEBUG_LMS);
	return ERR_NONE;
}

function GetLastErrorDesc()
{
	trivLogMsg("In GetLastErrorDesc", DEBUG_LMS);
	if (intError != ERR_NONE)
	{
		trivLogMsg("Returning API Error - " + strErrorDesc, DEBUG_LMS);
		return strErrorDesc;
	}
	else if (bTCLoaded && TCAPI_GetLastError() != ERR_NONE)
	{
		trivLogMsg("returning LMS Error " + strTCAPIErrorString + "\n" + strTCAPIErrorDiagnostic, DEBUG_LMS);
		return strTCAPIErrorString + "\n" + strTCAPIErrorDiagnostic;
	}
	trivLogMsg("Returning No Error", DEBUG_LMS);
	return "";
}

function SetErrorInfo(intErrorNumToSet, strErrorDescToSet)
{
	trivLogMsg("In SetErrorInfo - Num=" + intErrorNumToSet + " Desc=" + strErrorDescToSet, DEBUG_LMS);
	intError = intErrorNumToSet;
	strErrorDesc = strErrorDescToSet;
}

function ResetErrorStatus()
{
	intTCAPIError = '';
	strTCAPIErrorString = "";
	strTCAPIErrorDiagnostic = "";
}


function LMSCommit_()
{
	trivLogMsg("In LMSCommit", DEBUG_LMS);
	ResetErrorStatus();
	if (!bTCLoaded)
		return false;
	if (!blnOverrodeTime)
	{
		dTCEnd = new Date();
		AccumulateTime();
		dTCStart = new Date();
	}

	var stmt;
	var bCmi5PassedSent = false;
	var bCmi5CompSent = false;
	
	if(TinCanStatus === "passed"  && TinCanGetCmi5MoveOn(tc_driver, 'passed'))
		bCmi5PassedSent = true;

	if(TinCanStatus === "completed" && TinCanGetCmi5MoveOn(tc_driver, 'completed'))
		bCmi5CompSent = true; //Don't add to statement queue if already sent
	
	
	
	if (TinCanUpdPending && !(bTCLoaded && TinCanStatus == 'attempted')) // don't send attempted after we are loaded
	{
		stmt = {
				"verb" : {
					"id" : "http://adlnet.gov/expapi/verbs/" + ( bCmi5PassedSent ? "scored" : TinCanStatus),
					"display" : {
						"und" :  ( bCmi5PassedSent ? "scored" : TinCanStatus)
					}
				},
				"timestamp" : TinCanISODateString(new Date()),
				"version" : TinCanVersion,
                 "object": {
					"id" : tc_driver.activityId,
					"definition" : {
						"name" : {
							"en-US" : tc_driver.activityName
						},
						"description" : {
							"en-US" : tc_driver.activityDesc
						}
					}
				},
				"result" : {}
			};

		if (TinCanCompStatus !== '' || !TinCanProcessing)
			stmt.result.duration = ConvertToTime(GetSessionAccumulatedTime());
		
		//Completion status is forbidden in cmi5 only allowed for completed statement
		if (TinCanCompStatus !== '' && TinCanStatus == 'completed')
			stmt.result.completion = (TinCanCompStatus == 'true');
		if (TinCanSatStatus !== '' && TinCanStatus != 'completed')
			stmt.result.success = (TinCanSatStatus == 'true');
		if (TinCanScore !== '' && TinCanStatus != 'completed' )
			stmt.result.score = {
				"scaled" : parseInt(TinCanScore, 10) / 100,
				"raw" : parseInt(TinCanScore, 10),
				"min" : 0,
				"max" : 100
			};

		if(!bCmi5CompSent)	
			tcapi_cache.statementQueue.push(stmt);
		TinCanUpdPending = false;
	}
	if (tcapi_cache.statementQueue.length > 0)
	{
		TinCanSendMultiStatements(tc_driver, tcapi_cache.statementQueue);
		tcapi_cache.statementQueue = [];
	}
	return true;
}

function LMSCommit()
{
  return LMSCommit_();
}

function GetPreviouslyAccumulatedTime()
{
	trivLogMsg("In GetPreviouslyAccumulatedTime", DEBUG_LMS);
	ResetErrorStatus();
	if (!bTCLoaded)
		return 0;

	if (tcapi_cache.totalPrevDuration === null)
	{
		var result = TinCanGetInfo(tc_driver, 'cumulative_time');
		if (result === null)
		{
			result = 0;
		}
		tcapi_cache.totalPrevDuration = Number(result);
	}
	trivLogMsg("PreviouslyAccumulatedTime=" + tcapi_cache.totalPrevDuration, DEBUG_LMS);
	return tcapi_cache.totalPrevDuration;

}

function AccumulateTime()
{
	trivLogMsg(
			"In AccumulateTime dTCStart=" + dTCStart + " dTCEnd=" + dTCEnd + " intAccumulatedMS=" + intAccumulatedMS,
			DEBUG_LMS);
	if (dTCEnd != null && dTCStart != null)
	{
		intAccumulatedMS += (dTCEnd.getTime() - dTCStart.getTime());
		trivLogMsg("intAccumulatedMS=" + intAccumulatedMS, DEBUG_LMS);
	}
}

function GetSessionAccumulatedTime()
{
	trivLogMsg("In GetSessionAccumulatedTime", DEBUG_LMS);
	ResetErrorStatus();
	dTCEnd = new Date();
	AccumulateTime();
	if (dTCStart != null)
		dTCStart = new Date();

	dTCEnd = null;
	trivLogMsg("Returning " + intAccumulatedMS, DEBUG_LMS);
	return intAccumulatedMS;
}

function SetSessionTime(intMilliseconds)
{
	trivLogMsg("In SetSessionTime", DEBUG_LMS);
	ResetErrorStatus();
	if (!CheckValidInt(intMilliseconds))
	{
		SetErrorInfo(ERR_INVNUM, "Invalid intMilliseconds passed to SetSessionTime (not an integer), intMilliseconds="
				+ intMilliseconds);
		return false;
	}
	intMilliseconds = parseInt(intMilliseconds, 10);
	if (intMilliseconds < 0)
	{
		SetErrorInfo(ERR_INVNUM,
				"Invalid intMilliseconds passed to SetSessionTime (must be greater than 0), intMilliseconds="
						+ intMilliseconds);
		return false;
	}
	blnOverrodeTime = true;
	intTimeOverrideMS = intMilliseconds;
	return true;
}

function createValidIdentifier(str)
{
	return encodeURIComponent( stringToSlug(str) );
}

function Trim(str)
{
	return str.replace(/^\s*/, "").replace(/\s*$/, "");
}

function TCSetStatus(stat)
{
	trivLogMsg("In TCSetStatus " + stat, DEBUG_LMS);
	if (!bTCLoaded)
		return false;
	bTCStatusWasSet = true;

	TinCanStatus = stat;
	TinCanUpdPending = true;
	if (stat == 'attempted')
	{
		TinCanSatStatus = 'true';
		TinCanCompStatus = '';
		TinCanProcessing = true;
	}
	else if (stat == 'passed' || stat == 'completed')
	{
		TinCanSatStatus = 'true';
		TinCanCompStatus = 'true';
		TinCanProcessing = false;
	}
	else if (stat == 'failed')
	{
		TinCanSatStatus = 'false';
		TinCanCompStatus = 'true';
		TinCanProcessing = false;
	}
	return true;
}

function LMSGetBookmark_()
{
	trivLogMsg("In LMSGetBookmark");
	ResetErrorStatus();
	if (!bTCLoaded)
		return TinCanBookmark;

	if (TinCanBookmark == null || TinCanBookmark.length == 0)
	{
		TinCanBookmark = TinCanGetInfo(tc_driver, 'bookmark');
		if (TinCanBookmark === null)
			TinCanBookmark = "";
	}
	trivLogMsg("Bookmark=" + TinCanBookmark);
	return TinCanBookmark;
}

function LMSGetBookmark()
{
	return LMSGetBookmark_();
}

function LMSSetBookmark_(strHtml, strName)
{
	trivLogMsg("In LMSSetBookmark - strHtml=" + strHtml + ", strName=" + strName);
	ResetErrorStatus();
	if (!bTCLoaded || typeof(tc_driver) == "undefined" || tc_driver == null)
		return false;

	TinCanSetInfo(tc_driver, 'bookmark', strHtml);
	TinCanSendStatement(tc_driver, {
		verb : {
			"id" : "http://adlnet.gov/expapi/verbs/experienced",
			"display" : {
				"und" : "experienced"
			}
		},
		timestamp : TinCanISODateString(new Date()),
		version: TinCanVersion,
		object: {
			id : tc_driver.activityId + "/" +  strHtml,
			objectType : "Activity",
			definition : {
				name : {
					"en-US" : strName
				},
				description : {
					"en-US" : ""
				}
			}
		},
		context : {
			contextActivities : {
				parent : tc_driver.courseActivityObject,
				grouping : tc_driver.courseActivityObject
			}
		}
	}, function()
	{
	});
	TinCanBookmark = strHtml;
	return true;
}

function LMSSetBookmark(strHtml, strName)
{
	return LMSSetBookmark_(strHtml, strName);
}

function putSCORMInteractions_(id, obj, tim, typ, crsp, wgt, srsp, res, lat, txt, chc,answ)
{
	if (obj == 'null')
		obj = null;
	trivLogMsg("putSCORMInteractions [" + id + "][" + obj + "][" + tim + "][" + typ + "][" + crsp + "][" + wgt + "]["
			+ srsp + "][" + res + "][" + lat + "][" + txt + "][" + chc + "][" + answ + "]");
	return LMSRecordInteraction(id, srsp, (res === 'correct' ? true : false), crsp, txt, wgt, lat, obj, tim, typ, chc,answ);
}

function putSCORMInteractions(id, obj, tim, typ, crsp, wgt, srsp, res, lat, txt, chc,answ)
{
	return putSCORMInteractions_(id, obj, tim, typ, crsp, wgt, srsp, res, lat, txt, chc,answ);
}

function LMSTinCanStatement_(strVerb, strObj, strScore, activityName, activityDesc )
{
	trivLogMsg("In LMSTinCanStatement - strVerb=" + strVerb + ", strObj=" + strObj);

	// this looks like incomplete logic, if we are going to check for an object we should also treat it differently
	// if it comes in as an object, so that probably never happens...
	var strObj2 = strObj.indexOf('{') < 0 ?  createValidIdentifier(strObj) : strObj;
	getTcDriver( activityName, activityDesc ).then((tc_driver) => {
		var stmt = {
			verb : {
				"id" : "http://adlnet.gov/expapi/verbs/" + strVerb,
				"display" : {
					"und" : strVerb
				}
			},
			timestamp : TinCanISODateString(new Date()),
			version: TinCanVersion,
			object: {
				id : tc_driver.activityId + "/" + strObj2,
				definition : {
					name : {
						"en-US" : strObj
					}
				}
			},
			context : {
				contextActivities : {
					parent : tc_driver.courseActivityObject,
					grouping : tc_driver.courseActivityObject
				}
			},
			result : {}
		};

		if(strScore !=null && strVerb == 'scored')
		{
			stmt.result.duration = ConvertToTime(GetSessionAccumulatedTime());
			stmt.result.score = {
					"raw" : parseInt(strScore, 10),
					"min" : 0,
					"max" : 100
				};
		}
		else if (strScore != null && strVerb == 'progressed') {
			stmt.result.duration = ConvertToTime(GetSessionAccumulatedTime());
		
			if (!stmt.result.extensions)
				stmt.result.extensions = {}

			stmt.result.extensions = {
				"https://w3id.org/xapi/cmi5/context/extensions/progress": parseInt(strScore, 10) 
			};

		}
		else if (strScore !=null)
		{
			stmt.result.duration = ConvertToTime(GetSessionAccumulatedTime());
			
			stmt.result.success = (strVerb == 'passed' || strVerb == 'completed' ? true : false);
			stmt.result.score = {
				"raw" : parseInt(strScore, 10),
				"min" : 0,
				"max" : 100
			};
		}
		TinCanSendStatement(tc_driver, stmt, function()
		{
		});
		return true;
	});
}

function LMSTinCanStatement(strVerb, strObj, strScore)
{
  return LMSTinCanStatement_(strVerb, strObj, strScore);
}

function LMSTinCanSetStatus_(strVerb)
{
	trivLogMsg("In LMSTinCanSetStatus - strVerb=" + strVerb);

    TCSetStatus(strVerb);
    return;
}

function LMSTinCanSetStatus(strVerb)
{
  return LMSTinCanSetStatus_(strVerb);
}

function stringToSlug(str)
{
	str = str.replace(/^\s+|\s+$/g, ''); // trim
	str = str.toLowerCase();

	// remove accents, swap ñ for n, etc
	var from = "àáäâèéëêìíïîòóöôùúüûñç·/_,:;";
	var to = "aaaaeeeeiiiioooouuuunc------";
	for (var i = 0, l = from.length; i < l; i++)
		str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));

	str = str.replace(/[^a-z0-9 -]/g, '') // remove invalid chars
	.replace(/\s+/g, '-') // collapse whitespace and replace by -
	.replace(/-+/g, '-'); // collapse dashes

	return str;
}

function LMSSetProgressed_() 
{
	if( typeof(tc_driver)!='undefined' && tc_driver != null && 
	typeof(tc_driver.launchData)!='undefined' && tc_driver.launchData != null  )
	{
		var countCompleted = 0;
		var strState = '';
		var titleTracking = getDisplayWindow().trivPageTracking ? getDisplayWindow().trivPageTracking : (typeof(trivPageTracking)!="undefined" ? trivPageTracking: null);
		if(titleTracking == null)
		{
			var contentFrame = window.parent.document.getElementsByName("contentframe")[0];
			if(typeof(contentFrame)!= 'undefined' && contentFrame )
			{
				if(typeof(contentFrame.contentWindow.trivPageTracking)!= "undefined")
					titleTracking = contentFrame.contentWindow.trivPageTracking;
			}
		}		

		if (titleTracking) 
		{
			countCompleted = titleTracking.GetNumCompPages(titleTracking.title.c, 0);
				
			if(countCompleted == 0)
				countCompleted = 1;

			var progress = (countCompleted / titleTracking.numPages) * 100;
			if(progress == Infinity || progress == 0 || isNaN(progress))
				progress = 1;
			LMSTinCanStatement_('progressed', tc_driver.activityName, progress, tc_driver.activityName, tc_driver.activityDesc); 
		}
		
	}
}
